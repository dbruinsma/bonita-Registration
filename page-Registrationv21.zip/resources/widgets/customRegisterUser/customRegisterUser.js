(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customRegisterUser', function() {
    return {
      controllerAs: 'ctrl',
      controller: 
function($scope, $http){
  var server = window.location.search.match(/url=([^&]+)/);
      if (server && server.length > 1) {
        server = decodeURIComponent(server[1]);
      } else {
        server = window.location.protocol + "//" + window.location.hostname + ":8080";
      }

this.postEndpoint = function login (){
               console.log('scope.properties   '+JSON.stringify($scope.properties))  
        $http({
            method: 'POST',
            // headers: {'X-Bonita-API-Token': this.getCookie('X-Bonita-API-Token')},
            url: server+'/bonita/loginservice',
            data: '{"username":"registrationpage", "password":"registrationpage","redirect":false}'
        })
// 		}
.then(function createuser(response) {
            $http({
            method: 'POST',
            url: server+'/bonita/API/identity/user',
            // headers: {'X-Bonita-API-Token': this.getCookie('X-Bonita-API-Token')},
            data: $scope.properties.newuserData
			})
			.then(function success (response){
			    $scope.properties.newuser = response;
			    console.log('newusercreted '+$scope.properties.newuser);
			    assignMembership();
			}, function fail(response){
			     $scope.properties.newuser = response.data ||" failed to create new user";
			})
// 		}
		
})}

function assignMembership(response) {
            $http({
            method: 'POST',
            // headers: {'X-Bonita-API-Token': this.getCookie('X-Bonita-API-Token')},
            url: server+'/bonita/API/identity/membership',
            data: {
                      "user_id": $scope.properties.newuser.data.id,
                      "group_id":$scope.properties.groupid,
                      "role_id":$scope.properties.roleid
                    }
    
            })	.then(function success (response){
			    
			    console.log('membership assigned');
			    assignBTpatientKey();
            }, function fail(response){
			     alert(" failed to membership assigned");
			})
}
function assignBTpatientKey() {
              console.log('newuser scope '+$scope.properties.newuser);
             console.log('$scope.properties.registrationType  ' +$scope.properties.registrationType)
             if ($scope.properties.customuserinfoFieldId){
           
           $http({
            method: 'PUT',
            // headers: {'X-Bonita-API-Token': this.getCookie('X-Bonita-API-Token')},
            // $scope.properties.customuserinfoFieldId needs to be the id number for the custom user field to update
            url: server+'/bonita/API/customuserinfo/value/'+$scope.properties.newuser.data.id+'/'+$scope.properties.customuserinfoFieldId,
            data: '{"value":'+$scope.properties.btpatientkey+'}'
       })
                 .then(function success (response){
              console.log('bt patient key assigned');
			    startUserRegistrationProcess();
                     
                 })
} else {
console.log('nocustomuserinfo added');
startUserRegistrationProcess();
}}

function startUserRegistrationProcess(response) {
           
 $scope.properties.httpResponse = response;
          $http({
            method: 'POST',
            // headers: {'X-Bonita-API-Token': this.getCookie('X-Bonita-API-Token')},
            url: $scope.properties.startProcessRegisterURL,
            data: $scope.properties.startProcessRegisterData
          }).then(function success (response){
			    	$scope.properties.httpResponse = response;
			    console.log('newuser regisistration process started');
			    confirmandlogut();
            }, function fail(response){
			     console.log(" failed to staart newuser regisistration process");
			
                confirmandlogut();
            })
}


function confirmandlogut(){
        bootbox.confirm("Please check your email for login instructions", function redirect(){window.location = (server+"/bonita/logoutservice")})
        }
}
,
      template: '\n<div class="text-{{ properties.alignment }}">\n    <button\n        ng-class="\'btn btn-\' + properties.buttonStyle"\n        ng-click="ctrl.postEndpoint()"\n        type="button"\n        ng-disabled="properties.disabled || ctrl.busy" ng-bind-html="properties.caption | uiTranslate"></button>\n</div>\n'
    };
  });
