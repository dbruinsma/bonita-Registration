(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customApidocSearchforPatient', function() {
    return {
      controllerAs: 'ctrl',
      controller: /**
 * The controller is a JavaScript function that augments the AngularJS scope and exposes functions that can be used in the custom widget template
 * 
 * Custom widget properties defined on the right can be used as variables in a controller with $scope.properties
 * To use AngularJS standard services, you must declare them in the main function arguments.
 * 
 * You can leave the controller empty if you do not need it.
 */
function ($scope, $http) {
 
    this.postEndpoint = function() {
        $http({
            method: $scope.properties.action,
            url: $scope.properties.PostURL,
            data: $scope.properties.data
        }).then(function successCallback(response) {
            // this callback will be called asynchronously
            // when the response is available
            if (response.data.PatientSearchResult.TotalItemCount==1){
                var patient1 = response.data.PatientSearchResult.Items.PatientSearchResponse;
                }
            else if(response.data.PatientSearchResult.TotalItemCount>1){
                var patient1 = response.data.PatientSearchResult.Items.PatientSearchResponse[0];
                }
            else {
                var patient1 = "No Matching Patient Found";
                alert(patient1)
                }
            
            // var patient1 = response.data.PatientSearchResult.Items.PatientSearchResponse[0]
            var patientinfo ="<br><b>Address: </b> "+patient1.DeliveryAddress.AddressLine1+"<br><b>City: </b> "+patient1.DeliveryAddress.City+"<b>  Zip: </b> "+patient1.DeliveryAddress.PostalCode+"<br><b>Phone: </b> "+patient1.DeliveryPhone;
            $scope.properties.httpResponse = response;
            bootbox.confirm({
            message:"Is this your account? "+patientinfo,
                buttons: {
                            confirm: {
                                label: 'Yes',
                                className: 'btn-success'
                            },
                            cancel: {
                                label: 'No',
                                className: 'btn-danger'
                            }
                        },
                        callback: function (result) {
                            console.log('This was logged in the callback: ' + result);
                            $scope.properties.conf = result;
                        }
                    });
            // if(!alert($scope.properties.alertSuccess));

            //{window.location.reload();
                 console.log(response);
            //}
        }, function errorCallback(response) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
            
            alert($scope.properties.alertFailure)
           
        });
    }
    },
      template: '\n<div class="text-{{ properties.alignment }}">\n    <button\n        ng-class="\'btn btn-\' + properties.buttonStyle"\n        ng-click="ctrl.postEndpoint()"\n        type="button"\n        ng-disabled="properties.disabled || ctrl.busy" ng-bind-html="properties.caption | uiTranslate"></button>\n</div>\n'
    };
  });
